<!-- _coverpage.md -->

# Som的Github Pages个人主页

> 就算我是老实人，但√急也会跳墙。

- 没啥可写的
- 我也懒得写
- 快点进入主页吧您

[我的Github账户](https://github.com/SSSomSo)
[进入主页](/?id=hi)
